/**
 * Created by todd.elwood on 11/29/2017.
 */
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class Parser {

    private int rownbr;
    private String color;
    private String firstname;
    private String lastname;
    private String phonenumber;
    private String zipcode;
    private boolean validrow;
    private boolean validPhoneNumber;

    private static String PHONE_NUMBER = "\\d{3} \\d{3} \\d{4}";
    private static String PHONE_NUMBER2 = "(\\d{3})-\\d{3}-\\d{4}";


    public String getColor() {
        return color;
    }

    public String getFirstname() {
        return firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public String getPhonenumber() {
        return phonenumber;
    }

    public String getZipcode() {
        return zipcode;
    }

    public boolean getValidRow() {
        return validrow;
    }

    public int getRowNumber() {
        return rownbr;
    }

    public Parser(String line, int currentRow) {

        String[] split = line.split(",");
        //System.out.println("Split length " + split.length);
        int max_columns = split.length;


        validrow = false;
        rownbr = currentRow;
        validPhoneNumber = false;

        if (max_columns == 5) {

            if (VerifyZipCode(split[2].trim()) && VerifyColor(split[4].trim()) && VerifyPhoneNumber(split[3].trim())) {

                if (validPhoneNumber) {
                    color = split[4].trim();
                    firstname = split[0].trim();
                    lastname = split[1].trim();
                    phonenumber = split[3].trim();
                    zipcode = split[2].trim();
                    validrow = true;
                }
            } else if (VerifyZipCode(split[4].trim()) && VerifyColor(split[3].trim()) && VerifyPhoneNumber(split[2].trim())) {

                if (validPhoneNumber) {
                    color = split[3].trim();
                    firstname = split[0].trim();
                    lastname = split[1].trim();
                    phonenumber = split[2].trim();
                    zipcode = split[4].trim();
                    validrow = true;
                }
            }
        } //if (max_columns == 5) {
        if (max_columns == 4) {
            if (VerifyZipCode(split[2].trim()) && VerifyColor(split[1].trim()) && VerifyPhoneNumber(split[3].trim())) {
                if (VerifyWhiteSpaceString(split[0].trim())) {
                    String fullname = split[0].trim();
                    int totalLength = fullname.trim().length();
                    String fname = fullname.substring(0, RetrieveWhiteSpace(fullname));
                    String lname = fullname.substring(RetrieveWhiteSpace(fullname) + 1);
                    firstname = fname;
                    lastname = lname;
                } //if (VerifyWhiteSpaceString(split[i].trim())) {
                if (validPhoneNumber) {
                    color = split[1].trim();
                    phonenumber = split[3].trim();
                    zipcode = split[2].trim();
                    validrow = true;
                }
            }
        } //if (max_columns == 4) {

        if (validrow == false) {
            color = "";
            firstname = "";
            lastname = "";
            phonenumber = "";
            zipcode = "";
        }
    }

    public boolean VerifyColor(String evalColor) {
        //Verify if string is color

        boolean IsColor = false;

        String color = evalColor.toLowerCase();
        //String[] phonePattern = {"\\d{3} \\d{3} \\d{4}", "\(\\d{3}\)-\\d{3}-\\d{4}"};
        String[] colorPattern = {"[a-z]"};

        for (int i = 0; i < colorPattern.length; i++) {
            //String inputString = color;
            Pattern r = Pattern.compile(colorPattern[i]);
            Matcher m = r.matcher(color);
            if (m.find()) {
                //System.out.println("Success: Found Phone Number\n");
                IsColor = true;
                break;
            }
        }
        return IsColor;


 /*       boolean IsColor=false;
        try {
            List<String> color_name = new ArrayList<String>();
            color_name.add("red");
            color_name.add("yellow");
            color_name.add("purple");
            color_name.add("orange");
            color_name.add("blue");
            color_name.add("black");
            color_name.add("pink");
            String color = evalColor.toLowerCase();

            Set<String> set = new HashSet<String>(color_name);
            if (set.contains(color)) {
                IsColor = true;
                System.out.println("Success: Found Color " + color );
            }
            return IsColor;
        } catch (Exception e) {
            System.out.println("Color Not Found Error: \n" + e +"\n");
        }
        return IsColor; */
    }

    public boolean VerifyPhoneNumber(String evalPhoneNumber) {
        //Verify if string matches phone number pattern
        boolean IsPhoneNumber = false;

        //String[] phonePattern = {"\\d{3} \\d{3} \\d{4}", "\(\\d{3}\)-\\d{3}-\\d{4}"};
        String[] phonePattern = {"\\(?\\d{3}\\)?[-.\\s]?\\d{3}[-.\\s]?\\d{4}"};

        for (int i = 0; i < phonePattern.length; i++) {
            String inputString = evalPhoneNumber;
            Pattern r = Pattern.compile(phonePattern[i]);
            Matcher m = r.matcher(inputString);
            if (m.find()) {
                //System.out.println("Success: Found Phone Number\n");
                IsPhoneNumber = true;
                validPhoneNumber = true;
                break;
            }
        }
        return IsPhoneNumber;
    }


    public boolean VerifyZipCode(String evalZipCode) {
        //Verify if string matches zip code pattern

        boolean IsZipCode = false;
        String pattern = "^[0-9]{5}$";
        String inputString = evalZipCode;
        Pattern r = Pattern.compile(pattern);
        Matcher m = r.matcher(inputString);

        if (m.find()) {
            //System.out.println("Success: Found\n");
            IsZipCode = true;
        }
        return IsZipCode;
    }


    public boolean VerifyWhiteSpaceString(String evalString) {
        //Verify if white space exists in string
        boolean whitespacefound = false;
        if (evalString.indexOf(" ") > 0) {
            whitespacefound = true;
        }
        return whitespacefound;
    }

    public int RetrieveWhiteSpace(String evalString) {
        //Return white space location in string
        return evalString.indexOf(" ");
    }



}
