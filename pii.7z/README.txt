PII Project
=====================
1. Unzip the zip file into specific target folder.
2. The inputfile.txt file has test data.
3. Run the following command line to execute the PII.
	>java -cp json-simple-2.3.0.jar;. JSONGen -in inputfile.txt -out outputfile.txt
4. An outputfile.txt will be generated in JSON format. Open browser to view the JSON format.