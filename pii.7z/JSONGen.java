/**
 * Created by todd.elwood on 11/29/2017.
 */

import java.io.*;
import java.util.*;
import org.json.simple.JsonArray;
import org.json.simple.JsonObject;
import org.json.simple.Jsoner;



public class JSONGen {

    public static void main(String[] args) throws IOException {

        String inputFile=null;
        String outputFile=null;

        if (args.length != 4) {
            System.out.println("Add parameters '-in inputfile.txt -out outputfile.txt ");
            System.exit(0);
        } else if (args.length == 4) {
            if (args[0].equalsIgnoreCase("-in") && args[2].equalsIgnoreCase("-out")) {
                inputFile = args[1];
                outputFile = args[3];
            } else {
                System.out.println("Add parameters '-in inputfile.txt -out outputfile.txt ");
                System.exit(0);
            }
        }

        //List<String> rowsInputFile = new ArrayList<String>();
        ArrayList<String> rowsInputFile = new ArrayList<String>();
        rowsInputFile= (ArrayList<String>) retrieveAllRows(inputFile);
        ArrayList<Parser> validRowList = new ArrayList<Parser>();
        //LinkedList <Parser> validRowList = new LinkedList <Parser>();

        for (int i = 0; i < rowsInputFile.size(); i++) {

            boolean add = validRowList.add(new Parser(rowsInputFile.get(i), i));
        }

        sortJSON(validRowList);

        JsonObject json = new JsonObject();
        loadValidDataJson(json,validRowList);
        loadErrorDataJson(json,validRowList);

        createJsonFile(json,outputFile);
    }


    public static void sortJSON(List<Parser> list) {
        Collections.sort(list, new Comparator<Parser>() {
            public int compare(Parser p1, Parser p2) {
                int res =  p1.getLastname().compareToIgnoreCase(p2.getLastname());
                if (res != 0)
                    return res;
                return p1.getFirstname().compareToIgnoreCase(p2.getFirstname());
            }
        });
    }


    public static List<String> retrieveAllRows(String file) throws IOException {

//        String current = new java.io.File( "." ).getCanonicalPath();
//        System.out.println("Current dir:"+current);
//        String currentDir = System.getProperty("user.dir");
//        System.out.println("Current dir using System:" +currentDir);

        List<String> rowsInputFile = new ArrayList<String>();
        BufferedReader reader = new BufferedReader(new FileReader(file));
        String line;
        int count = 1;
        try {
            while ((line = reader.readLine()) != null) {
                rowsInputFile.add(line);
                System.out.println(count + ". " + line);
                count++;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        reader.close();
        System.out.println("Total rows evaluated " + rowsInputFile.size());
        return rowsInputFile;

    }

    public static void loadErrorDataJson(JsonObject json, ArrayList<Parser> rowList) {
        //Add error array data to JSON output
        ArrayList<Integer> errorList = new ArrayList<>();
        for (int n = 0; n < rowList.size(); n++) {

            JsonObject cust = new JsonObject();
            if (rowList.get(n).getValidRow()==false) {
                errorList.add(rowList.get(n).getRowNumber());
            }
        }

        JsonArray errlist = new JsonArray(Arrays.asList(errorList));
        json.put("errors",errorList);
    }

    public static void loadValidDataJson(JsonObject json,ArrayList<Parser> rowList) {
        //  public static void loadValidDataJson(JsonObject json,LinkedList<Parser> rowList) {
        //Add valid row array data to JSON output

        //ReorderingList rlist;
        //rlist = new ReorderingList();


        JsonArray custarr = new JsonArray();
        for (int n = 0; n < rowList.size(); n++) {

            //JsonObject cust = new JsonObject();
            if (rowList.get(n).getValidRow()) {
                JsonObject cust = new JsonObject();
/*                cust.put("zipcode", rowList.get(n).getZipcode());
                cust.put("zipcode", rowList.get(n).getZipcode());
                cust.put("phonenumber", phoneFormat(rowList.get(n).getPhonenumber()));
                cust.put("lastname", rowList.get(n).getLastname());
                cust.put("firstname", rowList.get(n).getFirstname());
                cust.put("color", rowList.get(n).getColor());*/

                cust.put("color", rowList.get(n).getColor());
                cust.put("firstname", rowList.get(n).getFirstname());
                cust.put("lastname", rowList.get(n).getLastname());
                cust.put("phonenumber", phoneFormat(rowList.get(n).getPhonenumber()));
                cust.put("zipcode", rowList.get(n).getZipcode());

                custarr.add(cust);
                //cust.remove(n);}
            } else {
                //cust.remove(n);
            }
        }
        json.put("entries",custarr);
    }

    public static void createJsonFile(JsonObject json,String outputfile) throws IOException {
        //Create JSON content file with 2 space indentation

        FileWriter file = new FileWriter(outputfile, false);
        try {
            file.write(Jsoner.prettyPrint(json.toJson(),2));
            file.flush();
        } catch (IOException e) {
            System.out.println("Error " + e);
        }
    }

    public static long getFileSize(String filename) {

        File file = new File(filename);
        if (!file.exists() || !file.isFile()) {
            System.out.println("File does not exist");
            return -1;
        }
        return file.length();
    }

    public static String phoneFormat(String phone) {

        String phoneTemp=phone;
        phoneTemp=phoneTemp.replaceAll("()","");
        phoneTemp=String.format("%s-%s-%s",phoneTemp.substring(0,3),phoneTemp.substring(4,7),phoneTemp.substring(8,12));
        return phoneTemp;
    }

}


